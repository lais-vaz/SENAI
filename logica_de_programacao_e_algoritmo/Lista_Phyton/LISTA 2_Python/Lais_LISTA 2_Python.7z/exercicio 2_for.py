#-*- coding: UTF-8 -*-

print("calcularemos a soma dos 50 primeiros números pares")
soma = 0

for i in range (1, 51):
    soma += 2 * i

print ("a soma dos números 1 até o 50 é: ",soma)
