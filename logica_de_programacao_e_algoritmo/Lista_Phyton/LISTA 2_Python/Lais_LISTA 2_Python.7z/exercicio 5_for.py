#-*- coding: UTF-8 -*-

print ("executaremos a tabuada do 0 ao 9")
for tabuada in range(0, 10): 
    for calculo in range (1, 11):
        print(tabuada,"*", calculo, "=",tabuada * calculo)

#1 * 2 = 2
