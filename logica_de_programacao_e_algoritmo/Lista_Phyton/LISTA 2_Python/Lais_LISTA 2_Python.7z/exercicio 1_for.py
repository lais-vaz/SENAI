#-*- coding: UTF-8 -*-

print("o valor final de repetições é 50")

contadora = 1

for i in range (1,51):
    print (i)

for l in range (51, 0, -1):
    print (l)
