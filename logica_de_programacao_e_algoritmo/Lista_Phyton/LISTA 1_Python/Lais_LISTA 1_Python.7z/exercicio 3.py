#-*- coding: UTF-8 -*-

print ("digite dois números e eu vou lhe dizer qual é o maior")

num1 = int(input("digite o primeiro número: "))
num2 = int(input("digite o segundo o número: "))

if num1 > num2:
    print ("primeiro número é o maior")

else:
    print ("segundo número é o maior")
    
