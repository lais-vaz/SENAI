#-*- coding: UTF-8 -*-

print ("digite dois núemros e eu te direi se o primeiro é divisível pelo segundo")

num1 = int(input("digite o primeiro número"))
num2 = int(input("digite o segundo número"))

if num1 % num2 == 0:
    print("o primeiro número é divisível pelo segundo")

else:
    print ("o primeiro número não é divisível pelo segundo")
