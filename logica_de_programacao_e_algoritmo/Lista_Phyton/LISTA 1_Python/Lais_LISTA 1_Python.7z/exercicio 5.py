#-*- coding: UTF-8 -*-

print("digite um número e eu lhe direi se é múltiplo de 3 ou não")

numero = int(input("digite um número"))

if numero %3 == 0:
    print ("esse número é múltuplo de 3")

else:
    print("esse número não é múltiplo de 3")

