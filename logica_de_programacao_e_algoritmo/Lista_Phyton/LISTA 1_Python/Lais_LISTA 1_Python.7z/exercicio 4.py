#-*- coding: UTF-8 -*-

print("digite um número intero e eu lhe direi se ele é impar ou par")

numero = int(input("digite um núemro: "))

if numero %2 == 0:
    print ("o número é par!")

else:
    print ("o número é impar!")
